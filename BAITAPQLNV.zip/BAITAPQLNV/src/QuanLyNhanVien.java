
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.io.IOException;

public class QuanLyNhanVien extends NhanVien implements ImplementQuanLyNhanVien {
	private static final long serialVersionUID = 1L;
	List<NhanVien> listNhanViens;
	private DocGhi docGhi = new DocGhi();;

	public void addNhanVien() {
		System.out.println("Ho va ten : ");
		setHoTen(input().toUpperCase());
		while (true) {
			System.out.println("Ngay/Thang/NamSinh (dd/MM/yyyy) : ");
			setNamSinh(input());
			if (DateUtils.isValidDate(getNamSinh())) {
				break;
			} else
				System.out.println("Erros :  dd/MM/yyyy . Vd: ngay 10 thang 10 nam 2010 nhap : 10/10/2010");
		}

		System.out.println("Dia chi : ");
		setDiaChi(input());
		// NhanVien nhanViens = new NhanVien("x", "11/10/1995","DN");
		NhanVien nhanViens = new NhanVien(getHoTen(), getNamSinh(), getDiaChi());
		docGhi.write(nhanViens);
	}

	public void findNhanVienTheoNamSinh() {
		int countFind = 0;
		int ns;
		while (true) {
			try {
				System.out.println("Nhap nam sinh cua nhan vien can tim: ");
				ns = Integer.valueOf(input());
				break;
			} catch (NumberFormatException ex) {
				System.out.println("Erros : " + ex.getMessage());
			}
		}
		System.out.println("***************RESUL FIND ***************");
		for (int i = 0; i < listNhanViens.size(); i++) {
			String[] ngayThangNam = listNhanViens.get(i).getNamSinh().split("/");
			if (Integer.valueOf(ngayThangNam[2]) == ns) {
				System.out.println("\t" + listNhanViens.get(i).toString());
				countFind++;
			} else if (i == listNhanViens.size() - 1 && countFind == 0) {
				System.out.println("khong tim thay nhan vien co nam sinh  " + ns);

			} else
				continue;

		}
	}

	public void findNhanVienTheoNgaySinh() {
		int countFind = 0;
		int ns;
		while (true) {
			try {
				System.out.println("Nhap ngay sinh cua nhan vien can tim: ");
				ns = Integer.valueOf(input());
				break;
			} catch (NumberFormatException ex) {
				System.out.println("Erros : " + ex.getMessage());
			}
		}
		System.out.println("***************RESUL FIND ***************");
		for (int i = 0; i < listNhanViens.size(); i++) {
			String[] ngayThangNam = listNhanViens.get(i).getNamSinh().split("/");
			if (Integer.valueOf(ngayThangNam[0]) == ns) {
				System.out.println("\t" + listNhanViens.get(i).toString());
				countFind++;
			} else if (i == listNhanViens.size() - 1 && countFind == 0) {
				System.out.println("khong tim thay nhan vien co ngay sinh  " + ns);

			} else
				continue;

		}
	}

	public void findNhanVienTheoThangSinh() {
		int countFind = 0;
		int ns;
		while (true) {
			try {
				System.out.println("Nhap thang sinh cua nhan vien can tim: ");
				ns = Integer.valueOf(input());
				break;
			} catch (NumberFormatException ex) {
				System.out.println("Erros : " + ex.getMessage());
			}
		}
		System.out.println("***************RESUL FIND ***************");
		for (int i = 0; i < listNhanViens.size(); i++) {
			String[] ngayThangNam = listNhanViens.get(i).getNamSinh().split("/");
			if (Integer.valueOf(ngayThangNam[1]) == ns) {
				System.out.println("\t" + listNhanViens.get(i).toString());
				countFind++;
			} else if (i == listNhanViens.size() - 1 && countFind == 0) {
				System.out.println("khong tim thay nhan vien co thang sinh  " + ns);

			} else
				continue;

		}
	}

	public void findNhanVienTheoNgayThangNamSinh() {
		int countFind = 0;
		String nTNS;
		while (true) {
			System.out.println("Ngay/Thang/NamSinh (dd/MM/yyyy) : ");
			nTNS = input();
			if (DateUtils.isValidDate(nTNS)) {
				break;
			} else
				System.out.println("Erros :  dd/MM/yyyy . Vd: ngay 10 thang 10 nam 2010 nhap : 10/10/2010");
		}
		String[] nTNSFind = nTNS.split("/");
		System.out.println("***************RESUL FIND ***************");
		for (int i = 0; i < listNhanViens.size(); i++) {
			String[] ngayThangNam = listNhanViens.get(i).getNamSinh().split("/");
			if (Integer.valueOf(ngayThangNam[2]) == Integer.valueOf(nTNSFind[2])
					&& Integer.valueOf(ngayThangNam[1]) == Integer.valueOf(nTNSFind[1])
					&& Integer.valueOf(ngayThangNam[0]) == Integer.valueOf(nTNSFind[0])) {
				System.out.println("\t" + listNhanViens.get(i).toString());
				countFind++;
			} else if (i == listNhanViens.size() - 1 && countFind == 0) {
				System.out.println("khong tim thay nhan vien co ngay/thang/namsinh  " + nTNS);

			} else
				continue;

		}
	}

	public void findNhanVienTheoTen() {
		int countFind = 0;
		try {
			listNhanViens = docGhi.read();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Nhap ten cua nhan vien can tim: ");
		String hT = input().toUpperCase();
		System.out.println("***************RESUL FIND  ***************");
		for (int i = 0; i < listNhanViens.size(); i++) {
			if (listNhanViens.get(i).getHoTen().contains(hT)) {
				System.out.println("\t" + listNhanViens.get(i).toString());
				countFind++;
			} else if (i == listNhanViens.size() - 1 && countFind == 0) {
				System.out.println("khong tim thay nhan vien co ten  " + hT);

			} else
				continue;

		}
	}

	public void FindNhanVienNTNS() {
		int selectFind;
		try {
			listNhanViens = docGhi.read();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		do {
			menuFindNhanVien();
			while (true) {
				try {
					System.out.println("Input number select : ");
					selectFind = Integer.valueOf(input());
					break;
				} catch (Exception ex) {
					System.out.println("Erros : " + ex.getMessage());
					System.out.println("Vui long nhap lai.");
					scanner.nextLine();
				}
			}
			switch (selectFind) {
			case 1:
				findNhanVienTheoNgaySinh();
				break;
			case 2:
				findNhanVienTheoThangSinh();
				break;
			case 3:
				findNhanVienTheoNamSinh();
				break;
			case 4:
				findNhanVienTheoNgayThangNamSinh();
				break;
			}
		} while (selectFind != 0);

	}

	public void sapXepNhanVienTheoTen() {
		List<NhanVien> listNV = null;
		try {
			listNV = docGhi.read();
			Collections.sort(listNV, new Comparator<NhanVien>() {
				@Override
				public int compare(NhanVien o1, NhanVien o2) {
					return o1.getHoTen().compareTo(o2.getHoTen());
				}
			});
			System.out.println("*******************Sau khi sap Xep*************");
			for (int i = 0; i < listNV.size(); i++) {
				System.out.println("\t" + listNV.get(i).toString());
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public void show() {
		try {

			List<NhanVien> readNhanViens = docGhi.read();

			System.out.println("show readNhanViens:" + readNhanViens.size());
			System.out.println("***************INFO***************");
			for (int i = 0; i < readNhanViens.size(); i++) {
				System.out.println("\t" + readNhanViens.get(i).toString());
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	@Override
	public String toString() {
		return "Nhan Vien " + super.toString();
	}

	public void menuFindNhanVien() {
		System.out.println("******************MENU*****************");
		System.out.println("\t1. Tim nhan vien theo ngay sinh.");
		System.out.println("\t2. Tim nhan vien theo thang sinh.");
		System.out.println("\t3. Tim nhan vien theo nam sinh.");
		System.out.println("\t4. Tim nhan vien theo ngay thang nam sinh.");
		System.out.println("\t0. Exit Find nhan vien.");

	}

	public void menuQuanLyNhanVien() {
		System.out.println("******************MENU*****************");
		System.out.println("\t1. Them nhan vien.");
		System.out.println("\t2. Tim nhan vien theo ngay thang nam sinh.");
		System.out.println("\t3. Tim nhan vien theo ten.");
		System.out.println("\t4. Sap xep nhan vien theo ten.");
		System.out.println("\t5. Hien thi thong tin nhan vien.");
		System.out.println("\t0. Exit.");

	}

}
