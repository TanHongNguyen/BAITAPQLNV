
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;
import java.io.EOFException;

public class DocGhi {
	private static final String NhanVien_FILE_NAME = "C:\\Users\\NARUTO\\Desktop\\HocJava\\NhanVien7.txt";

	public void write(NhanVien nhanVien) {
		FileOutputStream fout = null;
		ObjectOutputStream oos = null;
		try {
			// nếu file chưa lưu object nào thì ghi bình thường
			if (!hasObject(NhanVien_FILE_NAME)) {
				fout = new FileOutputStream(NhanVien_FILE_NAME);
				oos = new ObjectOutputStream(fout);
			} else {
				fout = new FileOutputStream(NhanVien_FILE_NAME, true);
				oos = new ObjectOutputStream(fout) {
					@Override
					protected void writeStreamHeader() throws IOException {
						reset();
					}
				};
			}

			oos.writeObject(nhanVien);
			System.out.println("Xong!");
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			closeStream(fout);
			closeStream(oos);

		}
	}

	public List<NhanVien> read() throws IOException {
		// List<NhanVien> NhanVienList;
		List<NhanVien> nhanVienList = new ArrayList<>();
		FileInputStream fis = null;
		ObjectInputStream ois = null;
		try {
			fis = new FileInputStream(NhanVien_FILE_NAME);
			ois = new ObjectInputStream(fis);
			NhanVien nv = null;
			while ((nv = (NhanVien) ois.readObject()) != null) {

				nhanVienList.add(nv);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (EOFException e) {
			// e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			closeStream(fis);
			closeStream(ois);
		}
		return nhanVienList;

	}

	public boolean hasObject(String NhanVien_FILE_NAME) {
		FileInputStream fi;
		boolean check = true;
		try {
			fi = new FileInputStream(NhanVien_FILE_NAME);
			ObjectInputStream inStream = new ObjectInputStream(fi);
			if (inStream.readObject() == null) {
				check = false;
			}
			inStream.close();
		} catch (FileNotFoundException e) {
			check = false;
		} catch (IOException e) {
			check = false;
		} catch (ClassNotFoundException e) {
			check = false;
			e.printStackTrace();
		}
		return check;
	}

	private void closeStream(InputStream is) {
		if (is != null) {
			try {
				is.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	private void closeStream(OutputStream os) {
		if (os != null) {
			try {
				os.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
