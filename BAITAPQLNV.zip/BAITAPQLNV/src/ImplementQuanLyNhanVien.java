

interface ImplementQuanLyNhanVien {

	public void addNhanVien();// Them nhan vien.

	public void findNhanVienTheoTen();// Tim nhan vien theo ten.

	public void findNhanVienTheoNgaySinh();// Tim nhan vien theo ngay sinh.

	public void findNhanVienTheoThangSinh();// tim nhan vien theo thang sinh.

	public void findNhanVienTheoNamSinh();// Tim nhan vien theo nam sinh.

	public void findNhanVienTheoNgayThangNamSinh();// Tim nhan vien theo ngay thang nam sinh.

	public void FindNhanVienNTNS();// Selection cac phuong thuc tim nhan vien theo ngay, thang, nam sinh.

	public void sapXepNhanVienTheoTen();// Sap xep nhan vien theo ten;

	public String toString();//

	public void show();// In ra thong tin tat ca nhan vien.

	public void menuFindNhanVien();// Menu tim nhan vien theo ten.

	public void menuQuanLyNhanVien();// Menu quan ly nhan vien.

}
