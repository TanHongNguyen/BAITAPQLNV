import java.util.Scanner;

public class MainQLNV {

	public static void menuMain() {
		QuanLyNhanVien quanLyNhanVien = new QuanLyNhanVien();
		Scanner scanner = new Scanner(System.in);
		int select;
		do {
			quanLyNhanVien.menuQuanLyNhanVien();
			while (true) {
				try {
					System.out.println("Input number select : ");
					select = scanner.nextInt();
					break;
				} catch (Exception ex) {
					System.out.println("Erros : " + ex.getMessage());
					System.out.println("Vui long nhap lai.");
					scanner.nextLine();
				}
			}
			switch (select) {
			case 1:
				quanLyNhanVien.addNhanVien();
				break;
			case 2:
				quanLyNhanVien.FindNhanVienNTNS();
				break;
			case 3:
				quanLyNhanVien.findNhanVienTheoTen();
				break;
			case 4:

				quanLyNhanVien.sapXepNhanVienTheoTen();
				System.out.println("List sau khi sap xep");

				break;
			case 5:
				quanLyNhanVien.show();
				break;
			}
		} while (select != 0);
		scanner.close();

	}

	public static void main(String[] args) {
		menuMain();

	}

}
